RSpec.describe "#pipeline_test"  do
	context "go" do
		it "true equal true" do 
			expect(true).to eq true
		end
	end
end